//
//  Bootstrapping.cpp
//  SimpleCurlMac
//

#include <cmath>
#include <iostream>
#include <iomanip>
#include <vector>
#include <cstdlib>
#include "Bootstrapping.h"
#include "Stock.h"
#include "Matrix.h"
#include "Earning.h"
#include <ctime>
#include <map>
#include <time.h>
using namespace std;
const int I = 30;//30 samples
const int J = 30;//30 stocks for each sample

Vector calAAR(int N, map<string, HistoPrice>& DataMap, vector<string>& StockList)
{
    Vector AAR;
    AAR.resize(2*N);
    for (int j = 0; j < J; j++)//30 stocks for one sample
    {
        if (DataMap[StockList[j]].AR.size() == 0)
        {
            DataMap[StockList[j]].CalculateReturn();
        }
        AAR += DataMap[StockList[j]].AR;
    }
    AAR = (1.0 /J) * AAR;//1*2N
    return AAR;
}
vector<Matrix> setsize(vector<Matrix>& V, int A, int B, int C)
{
    V.resize(A);
    for (int a = 0; a < A; a++)
    {
        V[a].resize(B);
        for (int b = 0; b < B; b++)
            V[a][b].resize(C);
    }
    return V;
}

vector<vector<string>> Calculation::RandomSelect()
{
    int length_Beat = groupmap["Beat"].size();
    int length_Meet = groupmap["Meet"].size();
    int length_Miss = groupmap["Miss"].size();
    vector<string> tempBeat = groupmap["Beat"];
    vector<string> tempMeet = groupmap["Meet"];
    vector<string> tempMiss = groupmap["Miss"];

    vector<string> SelectedBeat;
    vector<string> SelectedMeet;
    vector<string> SelectedMiss;

    vector<string> remainingBeat(length_Beat);
    vector<string> remainingMeet(length_Meet);
    vector<string> remainingMiss(length_Miss);

    vector<vector<string>> OnceSelect;//store 30 randomly selected stocks' symbols per group in a matrix

    for (int j = 0; j < J; j++)
    {
        int Beat_select = rand() % (length_Beat - j);
        string Beat_sym = tempBeat[Beat_select];
        SelectedBeat.push_back(Beat_sym);
        tempBeat.erase(tempBeat.begin() + Beat_select);

        int Meet_select = rand() % (length_Meet - j);
        string Meet_sym = tempMeet[Meet_select];
        SelectedMeet.push_back(Meet_sym);
        tempMeet.erase(tempMeet.begin() + Meet_select);

        int Miss_select = rand() % (length_Miss - j);
        string Miss_sym = tempMiss[Miss_select];
        SelectedMiss.push_back(Miss_sym);
        tempMiss.erase(tempMiss.begin() + Miss_select);
    }

    OnceSelect.push_back(SelectedBeat);
    OnceSelect.push_back(SelectedMeet);
    OnceSelect.push_back(SelectedMiss);

    return OnceSelect;
}

void Calculation::GetResults()
{
    setsize(SampleAAR, I, 3, 2 * N);
    setsize(SampleCAAR, I, 3, 2 * N);
    setsize(AARResult, 2 * N, 3, I);
    setsize(CAARResult, 2 * N, 3, I);
    setsize(Result, 3, 4, 2 * N);

    srand(time(NULL));
    for (int i = 0; i < I; i++) //Sample
    {
        //get one sample results
        vector<vector<string>> Select;
        Select = RandomSelect();

        for (int k = 0; k < 3; k++)//For each group
        {
            SampleAAR[i][k] = calAAR(N, DataMap, Select[k]);//1*2N, AAR result for sample i group k
            SampleCAAR[i][k] = calCAAR(SampleAAR[i][k]);//1*2N, CAAR result for sample i group k
            for (int t = 0; t < 2 * N; t++)
            {
                AARResult[t][k][i] = SampleAAR[i][k][t];//AAR for sample i group k on day t
                CAARResult[t][k][i] = SampleCAAR[i][k][t];//CAAR for sample i group k on day t
            }
        }
    }

    for (int k = 0; k < 3; k++)//group
    {
        for (int t = 0; t < 2 * N; t++)
        {
            Result[k][0][t] = GetAverage(AARResult[t][k]);//avg_AAR result for group k on day t
            Result[k][1][t] = GetSTD(AARResult[t][k]);//AAR_STD result for group k on day t
            Result[k][2][t] = GetAverage(CAARResult[t][k]);//avg_CAAR result for group k on day t
            Result[k][3][t] = GetSTD(CAARResult[t][k]);//CAAR_STD result for group k on day t
        }
    }
}
