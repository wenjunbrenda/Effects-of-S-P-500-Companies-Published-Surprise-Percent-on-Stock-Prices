//
//  simple_curl.h
//  SimpleCurlMac
//


#ifndef simple_curl_h
#define simple_curl_h

#include <stdio.h>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <locale>
#include <iomanip>
#include "curl/curl.h"
#include "Matrix.h"
using namespace std;

size_t write_data(void* ptr, int size, int nmemb, FILE* stream);
void* myrealloc(void* ptr, size_t size);
size_t write_data2(void* ptr, size_t size, size_t nmemb, void* data);
string getTimeinSeconds(string Time);
map<string, class HistoPrice> yfdata(map<string, string> day_0_map, vector<string> symbolList, int N);
map<string, class HistoPrice> cut_yfdata(map<string, class HistoPrice> histo_map, map<string, string> day_0_map, int N);
map<string, class HistoPrice> market_data(map<string,class HistoPrice> histo_map,vector<string> day0list, int N);
#endif /* simple_curl_h */
