//
//  Matrix.cpp
//  SimpleCurlMac
//


#include "Matrix.h"
#include <cmath>

Vector operator+(const Vector& V, const Vector& W)
{
    int d = V.size();
    Vector U(d);
    for (int j = 0; j < d; j++) U[j] = V[j] + W[j];
    return U;
}

Vector operator-(const Vector& V, const Vector& W)
{
    int d = V.size();
    Vector U(d);
    for (int j = 0; j < d; j++) U[j] = V[j] - W[j];
    return U;
}

Vector operator+(const double& a, const Vector& V)
{
    int d = V.size();
    Vector U(d);
    for (int j = 0; j < d; j++) U[j] = a + V[j];
    return U;
}

Vector operator*(const double& a, const Vector& V)
{
    int d = V.size();
    Vector U(d);
    for (int j = 0; j < d; j++) U[j] = a * V[j];
    return U;
}

double operator^(const Vector& V, const Vector& W)
{
    double sum = 0.0;
    int d = V.size();
    for (int j = 0; j < d; j++) sum = sum + V[j] * W[j];
    return sum;
}

ostream& operator<<(ostream& out, Vector& V)
{
    for (Vector::iterator itr = V.begin(); itr != V.end(); itr++)
        out << *itr << "   ";
    out << endl;
    return out;
}

ostream& operator<<(ostream& out, Matrix& W)//use ostream & operator<<(ostream & out, Vector & V)
{
    for (Matrix::iterator itr = W.begin(); itr != W.end(); itr++)
        out << *itr;
    out << endl;
    return out;
}

Vector operator+=(Vector& V, const Vector& W)
{
    int d = V.size();
    for (int j = 0; j < d; j++) V[j] = V[j] + W[j];
    return V;
}
double GetAverage(const Vector& V)
{
    int d = V.size();
    double sum = 0.0;
    for (int j = 0; j < d; j++)
        sum += V[j];
    return sum /d;
}
double GetSTD(const Vector& V)
{
    int d = V.size();
    double ave = GetAverage(V);
    double sum = 0.0;
    for (int j = 0; j < d; j++)
        sum += (V[j] - ave) * (V[j] - ave);
    return sqrt(sum /(d-1));
}

Vector calCAAR(const Vector& V)
{
    Vector CAAR;
    double prev = 0.0;
    int d = V.size();
    for (int j = 0; j < d; j++)
    {
        double next = prev + V[j];
        CAAR.push_back(next);
        prev = next;
    }
    return CAAR;
}

Vector calReturn(const Vector& V)
{
    Vector Return;
    int d = V.size();
    double x;
    for (int j = 1; j < d; j++)
    {
        x = (V[j] - V[j - 1]) / V[j - 1];
        Return.push_back(x);
    }
    return Return;
}
Vector calAR(const Vector& V, const Vector& W)
{
    Vector AR;
    AR = calReturn(V) - calReturn(W);
    return AR;
}
