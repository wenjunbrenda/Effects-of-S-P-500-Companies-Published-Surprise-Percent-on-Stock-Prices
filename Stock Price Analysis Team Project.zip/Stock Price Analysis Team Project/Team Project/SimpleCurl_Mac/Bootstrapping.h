//
//  Bootstrapping.h
//  SimpleCurlMac
//


#ifndef Bootstrapping_h
#define Bootstrapping_h

#include <stdio.h>
#include <cmath>
#include <iostream>
#include <iomanip>
#include <vector>
#include <cstdlib>
#include "Matrix.h"
#include "Stock.h"
using namespace std;

class Calculation
{
public:
    int N;
    map<string, HistoPrice> DataMap;//All the data
    map<string, vector<string>> groupmap;//Grouping result
    vector<Matrix> SampleAAR;//30(each sample)*3(Group Beat/Meet/Miss)*2N(day -N+1...0...N)
    vector<Matrix> SampleCAAR;//30(each sample)*3(Group Beat/Meet/Miss)*2N(day -N+1...0...N)
    vector<Matrix> AARResult;//2N(day -N+1...0...N)*3(Group Beat/Meet/Miss)*30(each sample)
    vector<Matrix> CAARResult;//2N(day -N+1...0...N)*3(Group Beat/Meet/Miss)*30(each sample)
    vector<Matrix> Result;//3(Group Beat/Meet/Miss)*4(avg_AAR/AAR_STD/avg_CAAR/CAAR_STD)*2N(day -N+1...0...N)
    Calculation(int N_, map<string, HistoPrice> DataMap_, map<string, vector<string>> groupmap_)//constructor with parameters
    {
        N = N_;
        DataMap = DataMap_;
        groupmap = groupmap_;
    }
    vector<vector<string>> RandomSelect();//Sampling, select 30 stocks from each group randomly
    void GetResults();//Do all the calculation
};

#endif /* Bootstrapping_h */
