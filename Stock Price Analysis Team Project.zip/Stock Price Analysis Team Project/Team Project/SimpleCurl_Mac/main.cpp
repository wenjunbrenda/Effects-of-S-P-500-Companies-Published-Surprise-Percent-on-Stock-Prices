//
//  main.cpp
//  SimpleCurlMac
//


#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <string>
#include <cmath>
#include <locale>
#include <iomanip>
#include <map>
#include "Stock.h"
#include "Earning.h"
#include "curl/curl.h"
#include "simple_curl.h"
#include "Bootstrapping.h"
#include "Matrix.h"
#include "Visualization.h"
#include "GrabData.h"
using namespace std;

void printvector(vector<string> a)
{
    for (auto i = a.begin(); i != a.end(); i++)
        cout << *i << ' ';
}

void printvector(vector<double> b)
{
    for (auto i = b.begin(); i != b.end(); i++)
        cout << *i << ' ';
}

void printmap(map<string, double> c)
{
    map<string, double>::iterator it;
    for (it = c.begin(); it != c.end(); it++)
    {
        cout << it->first << "-" << it->second << " ";
    }
}

void printmap(map<string, string> d)
{
    map<string, string>::iterator it;
    for (it = d.begin(); it != d.end(); it++)
    {
        cout << it->first << "-" << it->second << " ";
    }
}

void printmap(map<string, vector<string>> e)
{
    map<string, vector<string>>::iterator it;
    for (it = e.begin(); it != e.end(); it++)
    {
        cout << it->first;
        printvector(it->second);
    }
}

void printyfmap(map<string, class HistoPrice> f)
{
    map<string, class HistoPrice>::iterator it;
    for (it = f.begin(); it != f.end(); it++)
    {
        cout << it->first << ": ";
        printvector(it->second.price_date);
        printvector(it->second.historical_price);
        printvector(it->second.market_price);
        
    }
}

void printsmatrix(vector<vector<string>> smatrix)
{
    vector<vector<string>>::iterator it;
    for (it = smatrix.begin(); it != smatrix.end(); it++)
    {
        for (int i = 0; i <(*it).size(); i++)
            cout << (*it)[i] << ' ';
        cout << endl;
    }
}

void printbigmatrix(vector<Matrix>bigmat)
{
    vector<Matrix>::iterator it;
    for (it = bigmat.begin(); it != bigmat.end(); it++)
    {
        for (int x = 0; x < (*it).size(); x++)
        {
            for (int y = 0; y < 30; y++) {
                cout << (*it)[x][y];
                cout << " ";
            }
        }
        cout << endl;
    }
}

int main()
{
    // Global variables across different options
    int N = NULL;
    map<string, double> sym_to_sur;
    map<string, string> sym_to_d0;
    map<string, vector<string>> group3_map;
    map<string, class HistoPrice> in_yfdata;
    Earning Earn;
    
    while (1)
    {
        cout <<" "<< endl;
        cout << "1: Enter N and Load Historical Price Data for All Stocks." << endl;
        cout << "2: Enter Ticker to Find Information of One Specific Stock." << endl;
        cout << "3: Show Avg AAR, AAR STD, Avg CAAR, and CAAR STD for One Specific Group." << endl;
        cout << "4: Show CAAR Graphs for All 3 Groups." << endl;
        cout << "5: Exit the Program." << endl << endl;
        string old_opt;
        cout << "Please Enter the Option # to Find Information You Need: "; cin>>old_opt;
        cout << endl;
        int opt;
        vector<string> symbolist;
        vector<string> day0list;
        vector<double> surplist;
        try {opt = stoi(old_opt);}
        catch(const std::invalid_argument& ia){cout << "Exception: " << ia.what() << endl;
            cout << "Please Enter an Integer Between 1 and 5." << endl;
            continue;
        }
        if (opt!=1 && opt!=2 && opt!=3 && opt!=4 && opt!=5 && opt!=6)
        {
            cout << "Please Enter an Integer Between 1 and 5." << endl << endl;
            continue;
        }
        
        // menu option cases
        switch(opt){
            case 1:{
                    string old_N;
                    cout << "Please Enter N: "; cin >> old_N;
                    try{
                        N = stoi(old_N);
                    }
                    catch(const std::invalid_argument& ia)
                    {
                    cout << "Exception: " << ia.what() << endl;
                    cout << "Warning: Please Enter a valid integer N, and N should not be less than 30!" << endl;
                        continue;
                    }
                    if (N < 30) {
                        cout << "Warning: Please Enter a valid N, N should not be less than 30!" << endl;
                        N = NULL;
                        continue;
                    }
                        else { cout << "Thank You! Valid Data."; }
                    
                /*
                    fstream infile;
                    
                    infile.open("/Users/yinuotan/Desktop/NYU Study/2020 Spring/FRE 6883 _ Financial Computing/Team Project/Part5-MAC/SimpleCurl_Mac/SimpleCurl_Mac/Zacks.csv", ios::in);
    
                    string line;
                    vector<Stock> svec;
                    getline(infile, line);//skip the first line
                            
                    while (infile)
                    {
                        getline(infile, line);
                        if (!line.empty())
                        {
                            Stock S;
                            if (S.GetInputData(line) == 0)
                            {
                                svec.push_back(S);
                            }
                        }
                        //else return 1;
                    }
                            
                    for (int i = 0; i < svec.size(); i++)
                    {
                        symbolist.push_back(svec[i].sym);
                        day0list.push_back(svec[i].day_0);
                        surplist.push_back(svec[i].surpercent);
                    }
                            
                    //Mutating day0list into a specific data format that can be read by getTimeinSeconds in SimpleCurl.cpp
                    vector<string> newday0;
                    for (int i = 0; i < day0list.size(); i++)
                    {
                        string newday = day0list[i] + "T16:00:00";
                        newday0.push_back(newday);
                    }
                    //Testing statement for generated vectors:
                    //printvector(day0list);
                            
                    //Creating class Earning object to generate one-to-one map, and classify data into three groups:
                    Earn.symbol = symbolist;
                    Earn.day_0 = newday0;
                    Earn.surprise = surplist;
                    //Symbol to surprise percent map:
                    sym_to_sur = Earn.surprise_map();
                    //Symbol to day_0 map:
                    sym_to_d0 = Earn.day_0_map();
                    // printmap(group3_map);
                            
                    // get YF stocks' historical data and market data
                    in_yfdata = yfdata(sym_to_d0, symbolist, N);
                    in_yfdata = market_data(in_yfdata, day0list, N);
                    
                    // throw away stocks without information from sym_to_sur and Earn.surprise
                    sym_to_sur = Earn.cut_surprise_map(sym_to_sur, in_yfdata);
                
                    cout << endl;
                    cout << "Total Number of Available Stocks: " <<sym_to_sur.size() << endl;
                    cout << endl;
                            
                    //Group Name to group member stocks' symbols map:
                    group3_map = Earn.classify(sym_to_sur);
                    cout << "Number of Stocks in Group 'Beat': " << group3_map["Beat"].size() << endl;
                    cout << "Number of Stocks in Group 'Meet': " << group3_map["Meet"].size() << endl;
                    cout << "Number of Stocks in Group 'Miss': " << group3_map["Miss"].size() << endl;
                 */
                GrabData(N, symbolist, day0list, surplist, sym_to_sur, sym_to_d0, group3_map, in_yfdata, Earn);
                continue;
                }
            case 2:{
                if (N == NULL) {
                    N = 30;
                   /*
                    fstream infile;
                    
                    infile.open("/Users/yinuotan/Desktop/NYU Study/2020 Spring/FRE 6883 _ Financial Computing/Team Project/Part5-MAC/SimpleCurl_Mac/SimpleCurl_Mac/Zacks.csv", ios::in);
                    
                    string line;
                    vector<Stock> svec;
                    getline(infile, line);//skip the first line
                    
                    while (infile)
                    {
                        getline(infile, line);
                        if (!line.empty())
                        {
                            Stock S;
                            if (S.GetInputData(line) == 0)
                            {
                                svec.push_back(S);
                            }
                        }
                        //else return 1;
                    }
                    
                    for (int i = 0; i < svec.size(); i++)
                    {
                        symbolist.push_back(svec[i].sym);
                        day0list.push_back(svec[i].day_0);
                        surplist.push_back(svec[i].surpercent);
                    }
                    //Mutating day0list into a specific data format that can be read by getTimeinSeconds in SimpleCurl.cpp
                    vector<string> newday0;
                    for (int i = 0; i < day0list.size(); i++)
                    {
                        string newday = day0list[i] + "T16:00:00";
                        newday0.push_back(newday);
                    }
                    //Testing statement for generated vectors:
                    //printvector(day0list);
                        
                    //Creating class Earning object to generate one-to-one map, and classify data into three groups:
                    Earn.symbol = symbolist;
                    Earn.day_0 = newday0;
                    Earn.surprise = surplist;
                    //Symbol to surprise percent map:
                    sym_to_sur = Earn.surprise_map();
                    //Symbol to day_0 map:
                    sym_to_d0 = Earn.day_0_map();
                    //printmap(group3_map);
                        
                    //    printvector(symbolist);
                    in_yfdata = yfdata(sym_to_d0, symbolist, N);
                    in_yfdata = market_data(in_yfdata, day0list, N);
                    //    printyfmap(in_yfdata);
                        
                    sym_to_sur = Earn.cut_surprise_map(sym_to_sur, in_yfdata);
                    cout << endl;
                    cout << "Total Number of Available Stocks: " <<sym_to_sur.size() << endl;
                    cout << endl;
                    
                    //Group Name to group member stocks' symbols map:
                    group3_map = Earn.classify(sym_to_sur);
                    cout << "Number of Stocks in Group 'Beat': " << group3_map["Beat"].size() << endl;
                    cout << "Number of Stocks in Group 'Meet': " << group3_map["Meet"].size() << endl;
                    cout << "Number of Stocks in Group 'Miss': " << group3_map["Miss"].size() << endl;
                    */
                    GrabData(N, symbolist, day0list, surplist, sym_to_sur, sym_to_d0, group3_map, in_yfdata, Earn);
                    cout << endl;
                    cout << "Warning: N Has Not Been Set Yet, or N Has Been Changed to Number Smaller than 30. In Default, N is Set to be 30." << endl;
                    cout << endl;
                    }

                    string sym_bol;
                    cout << "Enter the Ticker of the Stock You Want to Find: "; cin>>sym_bol;
                    cout << endl;
                    if (sym_to_sur.find(sym_bol)==sym_to_sur.end())
                    {
                        cout << "Invalid Ticker, or Stock Inforamation Not Available" << endl << endl;
                        continue;
                    }
                    else{
                        vector<string> beat_vec = group3_map["Beat"];
                        vector<string> meet_vec = group3_map["Meet"];
                        vector<string> miss_vec = group3_map["Miss"];
                        if (find(beat_vec.begin(),beat_vec.end(),sym_bol)!=beat_vec.end())
                        {cout << "The Stock " << sym_bol << " Belongs to Group 'Beat'." << endl << endl;}
                        if (find(meet_vec.begin(),meet_vec.end(),sym_bol)!=meet_vec.end())
                        {cout << "The Stock " << sym_bol << " Belongs to Group 'Meet'." << endl << endl;}
                        if (find(miss_vec.begin(),miss_vec.end(),sym_bol)!=miss_vec.end())
                        {cout << "The Stock " << sym_bol << " Belongs to Group 'Miss'." << endl << endl;}
                        cout << "The Earning's Announcement Date of " << sym_bol << " is " << sym_to_d0[sym_bol].substr(0,10) << endl << endl;
                        cout << "The Earning's Surprise of " << sym_bol << " is " << sym_to_sur[sym_bol] << "%" << endl << endl;
                        cout << "The Historical Price of " << sym_bol << " is the following:" << endl;
                        printvector(in_yfdata[sym_bol].historical_price);
                        cout << endl;
                        continue;
                    }
            }
            case 3:{
                if (N == NULL) {
                    N = 30;
                    /*
                    fstream infile;
                
                    infile.open("/Users/yinuotan/Desktop/NYU Study/2020 Spring/FRE 6883 _ Financial Computing/Team Project/Part5-MAC/SimpleCurl_Mac/SimpleCurl_Mac/Zacks.csv", ios::in);
                  
                    string line;
                    vector<Stock> svec;
                    getline(infile, line);//skip the first line
                    
                    while (infile)
                    {
                        getline(infile, line);
                        if (!line.empty())
                        {
                            Stock S;
                            if (S.GetInputData(line) == 0)
                            {
                                svec.push_back(S);
                            }
                        }
                        //else return 1;
                    }
                    
                    for (int i = 0; i < svec.size(); i++)
                    {
                        symbolist.push_back(svec[i].sym);
                        day0list.push_back(svec[i].day_0);
                        surplist.push_back(svec[i].surpercent);
                    }
                    
                    //Mutating day0list into a specific data format that can be read by getTimeinSeconds in SimpleCurl.cpp
                    vector<string> newday0;
                    for (int i = 0; i < day0list.size(); i++)
                    {
                        string newday = day0list[i] + "T16:00:00";
                        newday0.push_back(newday);
                    }
                    //Testing statement for generated vectors:
                    //printvector(day0list);
                    
                    //Creating class Earning object to generate one-to-one map, and classify data into three groups:
                    Earn.symbol = symbolist;
                    Earn.day_0 = newday0;
                    Earn.surprise = surplist;
                    //Symbol to surprise percent map:
                    sym_to_sur = Earn.surprise_map();
                    //Symbol to day_0 map:
                    sym_to_d0 = Earn.day_0_map();
                    //printmap(group3_map);
                    
                    // printvector(symbolist);
                    in_yfdata = yfdata(sym_to_d0, symbolist, N);
                    in_yfdata = market_data(in_yfdata, day0list, N);
                    // printyfmap(in_yfdata);
                        
                    sym_to_sur = Earn.cut_surprise_map(sym_to_sur, in_yfdata);
                    cout << endl;
                    cout << "Total Number of Available Stocks: " <<sym_to_sur.size() << endl;
                    cout << endl;
                        
                    //Group Name to group member stocks' symbols map:
                    group3_map = Earn.classify(sym_to_sur);
                    cout << "Number of Stocks in Group 'Beat': " << group3_map["Beat"].size() << endl;
                    cout << "Number of Stocks in Group 'Meet': " << group3_map["Meet"].size() << endl;
                    cout << "Number of Stocks in Group 'Miss': " << group3_map["Miss"].size() << endl;
                    */
                    GrabData(N, symbolist, day0list, surplist, sym_to_sur, sym_to_d0, group3_map, in_yfdata, Earn);
                    cout << endl;
                    cout << "Warning: N Has Not Been Set Yet, or N Has Been Changed to Number Smaller than 30. In Default, N is Set to be 30." << endl;
                    cout << endl;
                    }
                   
                Calculation CAL(N, in_yfdata, group3_map);
                CAL.GetResults();
                vector<Matrix> FinalResult=CAL.Result;
                    
                string name;
                cout << "Please Enter the Group Name (Beat/Meet/Miss) You Would Like to Check: "; cin>>name;
                cout << endl;
                if (name!="Beat" && name!="Meet" && name!="Miss")
                {cout << "Invalid Input. You Should Enter Either 'Beat', 'Meet', or 'Miss'.";
                    continue;
                }
                if (name=="Beat")
                {
                    cout << "Below is the Average AAR of 'Beat' Group Across " << 2*N << " Days:" << endl;
                    printvector(CAL.Result[0][0]);
                    cout << endl;
                    cout << "------------------------------------------------------------------" << endl;
                    cout << "Below is the AAR STD of 'Beat' Group Across " << 2*N << " Days:" << endl;
                    printvector(CAL.Result[0][1]);
                    cout << endl;
                    cout << "------------------------------------------------------------------" << endl;
                    cout << "Below is the Average CAAR of 'Beat' Group Across " << 2*N << " Days:" << endl;
                    printvector(CAL.Result[0][2]);
                    cout << endl;
                    cout << "------------------------------------------------------------------" << endl;
                    cout << "Below is the CAAR STD of 'Beat' Group Across " << 2*N << " Days:" << endl;
                    printvector(CAL.Result[0][3]);
                }
                if (name=="Meet")
                {
                    cout << "Below is the Average AAR of 'Meet' Group Across " << 2*N << " Days:" << endl;
                    printvector(CAL.Result[1][0]);
                    cout << endl;
                    cout << "------------------------------------------------------------------" << endl;
                    cout << "Below is the AAR STD of 'Meet' Group Across " << 2*N << " Days:" << endl;
                    printvector(CAL.Result[1][1]);
                    cout << endl;
                    cout << "------------------------------------------------------------------" << endl;
                    cout << "Below is the Average CAAR of 'Meet' Group Across " << 2*N << " Days:" << endl;
                    printvector(CAL.Result[1][2]);
                    cout << endl;
                    cout << "------------------------------------------------------------------" << endl;
                    cout << "Below is the CAAR STD of 'Meet' Group Across " << 2*N << " Days:" << endl;
                    printvector(CAL.Result[1][3]);
                }
                if (name=="Miss")
                {
                    cout << "Below is the Average AAR of 'Miss' Group Across " << 2*N << " Days:" << endl;
                    printvector(CAL.Result[2][0]);
                    cout << endl;
                    cout << "------------------------------------------------------------------" << endl;
                    cout << "Below is the AAR STD of 'Miss' Group Across " << 2*N << " Days:" << endl;
                    printvector(CAL.Result[2][1]);
                    cout << endl;
                    cout << "------------------------------------------------------------------" << endl;
                    cout << "Below is the Average CAAR of 'Miss' Group Across " << 2*N << " Days:" << endl;
                    printvector(CAL.Result[2][2]);
                    cout << endl;
                    cout << "------------------------------------------------------------------" << endl;
                    cout << "Below is the CAAR STD of 'Miss' Group Across " << 2*N << " Days:" << endl;
                    printvector(CAL.Result[2][3]);
                }
                continue;
            }
            case 4:{
                if (N == NULL) {
                    N = 30;
                    /*
                    fstream infile;
                        
                    infile.open("/Users/yinuotan/Desktop/NYU Study/2020 Spring/FRE 6883 _ Financial Computing/Team Project/Part5-MAC/SimpleCurl_Mac/SimpleCurl_Mac/Zacks.csv", ios::in);
                    
                    string line;
                    vector<Stock> svec;
                    getline(infile, line);//skip the first line
                                   
                    while (infile){
                        getline(infile, line);
                        if (!line.empty())
                        {
                            Stock S;
                            if (S.GetInputData(line) == 0)
                            {
                                svec.push_back(S);
                            }
                        }
                        //else return 1;
                    }
                    
                    for (int i = 0; i < svec.size(); i++)
                    {
                        symbolist.push_back(svec[i].sym);
                        day0list.push_back(svec[i].day_0);
                        surplist.push_back(svec[i].surpercent);
                    }
                        
                    //Mutating day0list into a specific data format that can be read by getTimeinSeconds in SimpleCurl.cpp
                    vector<string> newday0;
                    for (int i = 0; i < day0list.size(); i++)
                    {
                        string newday = day0list[i] + "T16:00:00";
                        newday0.push_back(newday);
                    }
                    //Testing statement for generated vectors:
                    //printvector(day0list);
                        
                    //Creating class Earning object to generate one-to-one map, and classify data into three groups:
                    Earn.symbol = symbolist;
                    Earn.day_0 = newday0;
                    Earn.surprise = surplist;
                    //Symbol to surprise percent map:
                    sym_to_sur = Earn.surprise_map();
                    //Symbol to day_0 map:
                    sym_to_d0 = Earn.day_0_map();
                    //printmap(group3_map);
                        
                    // printvector(symbolist);
                    in_yfdata = yfdata(sym_to_d0, symbolist, N);
                    in_yfdata = market_data(in_yfdata, day0list, N);
                    // printyfmap(in_yfdata);
                        
                    sym_to_sur = Earn.cut_surprise_map(sym_to_sur, in_yfdata);
                    cout << endl;
                    cout << "Total Number of Available Stocks: " <<sym_to_sur.size() << endl;
                    cout << endl;
                        
                    //Group Name to group member stocks' symbols map:
                    group3_map = Earn.classify(sym_to_sur);
                    cout << "Number of Stocks in Group 'Beat': " << group3_map["Beat"].size() << endl;
                    cout << "Number of Stocks in Group 'Meet': " << group3_map["Meet"].size() << endl;
                    cout << "Number of Stocks in Group 'Miss': " << group3_map["Miss"].size() << endl;
                     */
                    GrabData(N, symbolist, day0list, surplist, sym_to_sur, sym_to_d0, group3_map, in_yfdata, Earn);
                    cout << endl;
                    cout << "Warning: N Has Not Been Set Yet, or N Has Been Changed to Number Smaller than 30. In Default, N is Set to be 30." << endl;
                    cout << endl;
                    }
                
                Calculation CAL(N, in_yfdata, group3_map);
                CAL.GetResults();
                
                vector <int> Days(2*N);
                for (int i = 0; i < 2*N; i++)
                {
                    Days[i] = i -(N-1);
                }
                 
                DisplayGraph(Days, CAL.Result[0][2], CAL.Result[1][2], CAL.Result[2][2],2*N);
               // DisplayGraph(Days, CAL.Result[0][2], 2*N);
                
               // WriteToExcel(Days, CAL.Result[0][2], CAL.Result[1][2], CAL.Result[2][2],2*N);
                
                continue;
            }
            case 5:{
                cout << "Exiting the Program ......" << endl;
                return 0;
            }
            }
    //User Enter N:

    /*
    Calculation CAL(N, in_yfdata, group3_map);
    CAL.GetResults();
    vector<Matrix> FinalResult=CAL.Result;
    printbigmatrix(FinalResult);
     */

        }
        return 0;
    }
