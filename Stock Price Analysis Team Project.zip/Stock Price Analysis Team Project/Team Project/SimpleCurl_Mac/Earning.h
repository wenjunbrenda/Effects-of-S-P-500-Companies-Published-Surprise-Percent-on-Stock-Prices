//
//  Earning.h
//  SimpleCurlMac
//


#ifndef Earning_h
#define Earning_h

#include <map>
#include <string>
#include <vector>
#include "Stock.h"
#include "Matrix.h"

using namespace std;

class Earning
{
public:
//    class variables
    vector<string> symbol;
    vector<string> day_0;
    Vector surprise;

//    constructor with parameters
    Earning(){};
    Earning(vector<string> symbol_, vector<string> day_0_, Vector surprise_)
    {
        symbol = symbol_;
        day_0 = day_0_;
        surprise = surprise_;
    }
    
// create one-to-one maps (symbol -> surprise) and (symbol -> announcement date)
    map<string,double> surprise_map();
    map<string,string> day_0_map();
    
// create a function which maps "beat", "meet" and "miss" to vectors of symbols
    map<string,vector<string>> classify(map<string,double> s_map);
    
// create a function that eliminated stocks with no price and date information
    map<string,double> cut_surprise_map(map<string,double> s_map,map<string,class HistoPrice> histo_map);
};

#endif /* Earning_h */
