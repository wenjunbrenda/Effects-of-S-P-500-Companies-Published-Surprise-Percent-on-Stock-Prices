//
//  Visualization.h
//  SimpleCurlMac
//


#ifndef Visualization_h
#define Visualization_h
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <vector>
#include "Stock.h"

using namespace std;

void DisplayGraph(vector<int> Days, vector<double> Beat, vector<double> Meet, vector<double> Miss,int dataSize);

// Print line for only one group, not used in this project
void DisplayGraph(vector<int> Days, vector<double> Group, int dataSize);

// Not used in this project
//void WriteToExcel (vector<int> Days, vector<double> Beat, vector<double> Meet, vector<double> Miss, int dataSize);

// Not used in the project
//void WriteToExcel (vector<string> Ticker, map<string,class HistoPrice> yf_data);

#endif /* Visualization_h */
