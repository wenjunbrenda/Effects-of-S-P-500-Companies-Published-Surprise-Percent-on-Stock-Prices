//
//  GrabData.h
//  SimpleCurlMac
//


#ifndef GrabData_h
#define GrabData_h

void GrabData(int N, vector<string> & symbolist, vector<string> & day0list,vector<double> & surplist, map<string, double> & sym_to_sur, map<string, string> & sym_to_d0, map<string, vector<string>> & group3_map, map<string, class HistoPrice> & in_yfdata, Earning & Earn);

#endif /* GrabData_h */
