//
//  GrabData.cpp
//  SimpleCurlMac
//


#include <stdio.h>
#include "iostream"
#include <fstream>
#include <vector>
#include <sstream>
#include <string>
#include <cmath>
#include <locale>
#include <iomanip>
#include <map>
#include "Stock.h"
#include "Earning.h"
#include "curl/curl.h"
#include "simple_curl.h"
#include "Bootstrapping.h"
#include "Matrix.h"
using namespace std;

void GrabData(int N, vector<string> & symbolist, vector<string> & day0list,vector<double> & surplist, map<string, double> & sym_to_sur, map<string, string> & sym_to_d0, map<string, vector<string>> & group3_map, map<string, class HistoPrice> & in_yfdata, Earning & Earn)
{
    fstream infile;
                    
    infile.open("/Users/yinuotan/Desktop/NYU Study/2020 Spring/FRE 6883 _ Financial Computing/Team Project/Part5-MAC/SimpleCurl_Mac/SimpleCurl_Mac/Zacks.csv", ios::in);

    string line;
    vector<Stock> svec;
    getline(infile, line);//skip the first line
                    
    while (infile)
    {
        getline(infile, line);
        if (!line.empty())
        {
            Stock S;
            if (S.GetInputData(line) == 0)
            {
                svec.push_back(S);
            }
        }
        //else return 1;
    }
                    
    for (int i = 0; i < svec.size(); i++)
    {
        symbolist.push_back(svec[i].sym);
        day0list.push_back(svec[i].day_0);
        surplist.push_back(svec[i].surpercent);
    }
                            
    //Mutating day0list into a specific data format that can be read by getTimeinSeconds in SimpleCurl.cpp
    vector<string> newday0;
    for (int i = 0; i < day0list.size(); i++)
    {
        string newday = day0list[i] + "T16:00:00";
        newday0.push_back(newday);
    }
    //Testing statement for generated vectors:
    //printvector(day0list);
                            
    //Creating class Earning object to generate one-to-one map, and classify data into three groups:
    Earn.symbol = symbolist;
    Earn.day_0 = newday0;
    Earn.surprise = surplist;
    //Symbol to surprise percent map:
    sym_to_sur = Earn.surprise_map();
    //Symbol to day_0 map:
    sym_to_d0 = Earn.day_0_map();
    // printmap(group3_map);
                            
    // get YF stocks' historical data and market data
    in_yfdata = yfdata(sym_to_d0, symbolist, N);
    in_yfdata = market_data(in_yfdata, day0list, N);
                    
    // throw away stocks without information from sym_to_sur and Earn.surprise
    sym_to_sur = Earn.cut_surprise_map(sym_to_sur, in_yfdata);
                
    cout << endl;
    cout << "Total Number of Available Stocks: " <<sym_to_sur.size() << endl;
    cout << endl;
                            
    //Group Name to group member stocks' symbols map:
    group3_map = Earn.classify(sym_to_sur);
    cout << "Number of Stocks in Group 'Beat': " << group3_map["Beat"].size() << endl;
    cout << "Number of Stocks in Group 'Meet': " << group3_map["Meet"].size() << endl;
    cout << "Number of Stocks in Group 'Miss': " << group3_map["Miss"].size() << endl;
}
