//
//  Visualization.cpp
//  SimpleCurlMac
//


#include "Visualization.h"
#include <vector>
using namespace std;

void DisplayGraph(vector<int> Days, vector<double> Beat, vector<double> Meet, vector<double> Miss,int dataSize)
{
    FILE* gnuplotPipe, * tempDataFile;
    
    const char* tempDataFileName1 = "Beat";
    const char* tempDataFileName2 = "Meet";
    const char* tempDataFileName3 = "Miss";
    double y1, y2, y3;
    int x;
    int i;
    
    gnuplotPipe = popen("/opt/local/bin/gnuplot","w");  // Open a pipe to gnuplot
    
    if (gnuplotPipe) {
        fprintf(gnuplotPipe, "set title \"CAAR\"font \"Helvetica, 16\"\n");
        fprintf(gnuplotPipe, "set xlabel \"Days\"font \"Helvetica, 16\"\n");
        fprintf(gnuplotPipe, "set ylabel \"Percentage\"font \"Helvetica, 16\"\n");
       // fprintf(gnuplotPipe, "set yrange [-0.1:0.1]\n");
        fprintf(gnuplotPipe, "max=%d\n",dataSize/2);
        fprintf(gnuplotPipe, "min=%d\n",-dataSize/2);
        fprintf(gnuplotPipe, "set xrange [min:max]\n");
        fprintf(gnuplotPipe, "plot \"%s\" with lines\ lc 1\ lw 2, \"%s\" with lines\ lc 2\ lw 2, \"%s\" with lines\ lc 7\ lw 2\n", tempDataFileName1, tempDataFileName2, tempDataFileName3);
        //fprintf(gnuplotPipe, "plot \"%s\"with lines, \"%s\" with lines, \"%s\" with lines\n", tempDataFileName1, tempDataFileName2, tempDataFileName3);
        fflush(gnuplotPipe);
        
        tempDataFile = fopen(tempDataFileName1, "w");
        for (i = 0; i < dataSize; i++) {
            x = Days[i];
            y1 = Beat[i];
            
            fprintf(tempDataFile, "%d %lf\n", x, y1);
        }
        fclose(tempDataFile);
        
        tempDataFile = fopen(tempDataFileName2, "w");
        for (i = 0; i < dataSize; i++) {
            x = Days[i];
            y2 = Meet[i];
            fprintf(tempDataFile, "%d %lf\n", x, y2);
        }
        fclose(tempDataFile);
        
        tempDataFile = fopen(tempDataFileName3, "w");
        for (i = 0; i < dataSize; i++) {
            x = Days[i];
            y3 = Miss[i];
            fprintf(tempDataFile, "%d %lf\n", x, y3);
        }
        fclose(tempDataFile);
        
        // printf("press enter to continue...");
        getchar();
        //remove(tempDataFileName1);
        //remove(tempDataFileName2);
        //remove(tempDataFileName3);
        fprintf(gnuplotPipe, "exit \n");
        pclose(gnuplotPipe);
    }
    else {
        printf("gnuplot not found...");
    }
}


void DisplayGraph(vector<int> Days, vector<double> Group, int dataSize)
{
    FILE* gnuplotPipe, * tempDataFile;
    
    const char* tempDataFileName1 = "Beat";
    //const char* tempDataFileName2 = "Meet";
    //const char* tempDataFileName3 = "Miss";
    double y1;
    int x;
    int i;
    
    gnuplotPipe = popen("/opt/local/bin/gnuplot","w");  // Open a pipe to gnuplot
    
    if (gnuplotPipe) {
        
        fprintf(gnuplotPipe, "plot \"%s\" with lines\n", tempDataFileName1);
        fflush(gnuplotPipe);
        tempDataFile = fopen(tempDataFileName1, "w");
        for (i = 0; i < dataSize; i++) {
            x = Days[i];
            y1 = Group[i];
            
            fprintf(tempDataFile, "%d %lf\n", x, y1);
        }
        fclose(tempDataFile);
        
        // printf("press enter to continue...");
        getchar();
        //remove(tempDataFileName1);
        //remove(tempDataFileName2);
        //remove(tempDataFileName3);
        fprintf(gnuplotPipe, "exit \n");
    }
    else {
        printf("gnuplot not found...");
    }
}

void WriteToExcel (vector<int> Days, vector<double> Beat, vector<double> Meet, vector<double> Miss, int dataSize)
{
    ofstream fout;
    fout.open("/Users/yinuotan/Desktop/Data.csv",ios::app);
    
    fout << "Days, Beat, Meet, Miss" << endl;
    
    for (int i = 0; i < dataSize; i++)
    {
        fout << Days[i] << ",";
        fout << Beat[i] << ",";
        fout << Meet[i] << ",";
        fout << Miss[i] << endl;
    }
}

void WriteToExcel (vector<string> Ticker, map<string,class HistoPrice> yf_data)
{
    ofstream fout;
    fout.open("/Users/yinuotan/Desktop/stock.csv",ios::app);
    
    fout << "Ticker,";
    
    for (int i = -60; i < 60; i++)
    {
        fout << "Day" << i << ",";
    }
    fout << endl;
    
    for (vector<string>::iterator itr=Ticker.begin();itr!=Ticker.end();itr++)
    {
        fout << *itr << ",";
        for (int i=0; i<121; i++)
        {
            fout << yf_data[*itr].historical_price[i] << ",";
        }
        fout << endl;
        for (int i=0; i<121; i++)
        {
            fout << yf_data[*itr].market_price[i] << ",";
        }
        fout << endl;
    }
}
