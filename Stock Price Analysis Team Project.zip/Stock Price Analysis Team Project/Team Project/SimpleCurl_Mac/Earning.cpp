//
//  Earning.cpp
//  SimpleCurlMac
//


#include <stdio.h>
#include <map>
#include <string>
#include <vector>
#include "Earning.h"
#include "Stock.h"
#include "Matrix.h"
using namespace std;

map<string,double> Earning:: surprise_map()
{
    long n = symbol.size();
    map<string,double> s_map;
    for (int i = 0; i < n; i++)
    {
        s_map.insert(pair<string, double>(symbol[i],surprise[i]));
    }
    return s_map;
}

 
map<string,string> Earning:: day_0_map()
{
    long n = symbol.size();
    map<string,string> d_map;
    for (int i = 0; i < n; i++)
    {
        d_map.insert(pair<string, string>(symbol[i],day_0[i]));
    }
    return d_map;
}

map<string,vector<string>> Earning:: classify(map<string,double> s_map)
{
    map<string,vector<string>> groups;
    vector<string> beat;
    vector<string> meet;
    vector<string> miss;
    int divider = int(s_map.size()/3);
    sort(surprise.begin(),surprise.end());
    double lower_threshold = surprise[divider];
    double higher_threshold = surprise[divider*2];
    map<string,double>::iterator itr;
    for (itr = s_map.begin(); itr != s_map.end(); itr++)
    {
        if (itr->second < lower_threshold) {miss.push_back(itr->first);}
        else if (itr->second > higher_threshold) {beat.push_back(itr->first);}
        else {meet.push_back(itr->first);}
    }
    groups.insert(pair<string, vector<string>>("Beat",beat));
    groups.insert(pair<string, vector<string>>("Meet",meet));
    groups.insert(pair<string, vector<string>>("Miss",miss));
    return groups;
}

map<string,double> Earning::cut_surprise_map(map<string,double> s_map,map<string,class HistoPrice> histo_map)
{
    Vector new_surprise;
    for (map<string,class HistoPrice>::iterator itr = histo_map.begin(); itr!=histo_map.end(); itr++)
    {
        if (itr->second.historical_price.size()==0 || itr->second.market_price.size()==0 || itr->second.price_date.size()==0)
        {
            s_map.erase(itr->first);
        }
        else {
            int index = int(distance(histo_map.begin(), itr));
            new_surprise.push_back(surprise[index]);
        }
    }
    this->surprise = new_surprise;
    return s_map;
}
