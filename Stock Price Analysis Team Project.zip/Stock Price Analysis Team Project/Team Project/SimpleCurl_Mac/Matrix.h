//
//  Matrix.h
//  SimpleCurlMac
//

#ifndef Matrix_h
#define Matrix_h

#include <stdio.h>
#include <vector>
#include <iostream>

using namespace std;

typedef vector<double> Vector;
typedef vector<Vector> Matrix;

Vector operator+(const double& a, const Vector& V);
Vector operator+(const Vector& V, const Vector& W);
Vector operator-(const Vector& V, const Vector& W);
Vector operator*(const double& a, const Vector& V);
Vector operator+=(Vector& V, const Vector& W);
ostream& operator<<(ostream& out, Vector& V);
ostream& operator<<(ostream& out, Matrix& W);
double GetAverage(const Vector& V);
double GetSTD(const Vector& V);
Vector calCAAR(const Vector& V);
Vector calReturn(const Vector& V);
Vector calAR(const Vector& V, const Vector& W);

#endif /* Matrix_h */
