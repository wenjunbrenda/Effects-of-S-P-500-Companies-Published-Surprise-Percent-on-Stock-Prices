//
//  Stock.h
//  SimpleCurlMac
//


#ifndef Stock_h
#define Stock_h

#include <map>
#include <string>
#include <vector>
#include <time.h>
#include <stdio.h>
#include <cmath>
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include "Matrix.h"
using namespace std;

class HistoPrice
{
public:
    Vector market_price; // for market
    Vector historical_price; // for stock
    vector<string> price_date; // corresponding date
    Vector AR;// abnormal return

    // default constructor
    HistoPrice() {}

    // constructor with parameters
    HistoPrice(Vector a_, vector<string> b_, Vector c_)
    {
        historical_price = a_;
        price_date = b_;
        market_price = c_;
    }

    int CalculateReturn();// calculate AR
};

class Stock
{
public:
    string sym;
    string day_0;
    double surpercent;
    int GetInputData(string sval);
};
#endif /* Stock_h */
