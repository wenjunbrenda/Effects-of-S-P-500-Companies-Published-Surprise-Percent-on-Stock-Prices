//
//  Stock.cpp
//  SimpleCurlMac
//


#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <time.h>
#include "Stock.h"
#include "Matrix.h"
#include <iostream>

using namespace std;

int HistoPrice::CalculateReturn()
{
    AR = calAR(historical_price, market_price);
    return 0;
}

int Stock::GetInputData(string sval)
{
    string temp;
    stringstream datalist(sval);

    //getline(datalist, sval, ' ');
    //Get Stock Symbol:
    //string symin;
    getline(datalist, temp, ',');
    sym = temp;


    //Get Stock Announcement Date (Day0):
    //string D0;
    getline(datalist, temp, '/');
    string m = temp;
    if (m.length() == 1) { m = "0" + m; }

    if (!temp.empty()) { getline(datalist, temp, '/'); }
    string d = temp;
    if (d.length() == 1) { d = "0" + d; }

    if (!temp.empty()) { getline(datalist, temp, ','); }
    string y = temp;
    if (y.length() == 2) { y = "20" + y; }
    day_0 = y + "-" + m + "-" + d;


    //Get Surprise percent number:
    //string Surp;
    getline(datalist, temp, '%');
    surpercent = stod(temp);

    return 0;
}
